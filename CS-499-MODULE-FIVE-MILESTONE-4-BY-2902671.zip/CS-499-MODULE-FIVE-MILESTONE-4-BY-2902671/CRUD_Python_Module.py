from pymongo import MongoClient
from typing import Dict, List

class AnimalShelter:
    """CRUD operations for Animal collection in MongoDB"""

    def __init__(self, username: str, password: str):
        """
        Initialize MongoDB connection
        """
        try:
            self.client = MongoClient(
                f'mongodb://{username}:{password}@localhost:27017/?authSource=admin'
            )
            self.database = self.client["aac"]
            self.collection = self.database["animals"]
        except Exception as e:
            print(f"Connection Error: {e}")

    # -------------------------
    # CREATE
    # -------------------------
    def create(self, data: Dict) -> bool:
        """
        Insert a document into the collection
        """
        try:
            if data and isinstance(data, dict):
                self.collection.insert_one(data)
                return True
            return False
        except Exception as e:
            print(f"Create Error: {e}")
            return False

    # -------------------------
    # READ
    # -------------------------
    def read(self, query: Dict = {}) -> List[Dict]:
        """
        Query documents from the collection
        """
        try:
            if isinstance(query, dict):
                result = self.collection.find(query)
                return list(result)
            return []
        except Exception as e:
            print(f"Read Error: {e}")
            return []

    # -------------------------
    # UPDATE
    # -------------------------
    def update(self, query: Dict, new_values: Dict) -> int:
        """
        Update documents in the collection
        """
        try:
            if isinstance(query, dict) and isinstance(new_values, dict):
                result = self.collection.update_many(query, {"$set": new_values})
                return result.modified_count
            return 0
        except Exception as e:
            print(f"Update Error: {e}")
            return 0

    # -------------------------
    # DELETE
    # -------------------------
    def delete(self, query: Dict) -> int:
        """
        Delete documents from the collection
        """
        try:
            if isinstance(query, dict):
                result = self.collection.delete_many(query)
                return result.deleted_count
            return 0
        except Exception as e:
            print(f"Delete Error: {e}")
            return 0