from pymongo import MongoClient
from pymongo.errors import PyMongoError
from typing import Dict, List


class AnimalShelter:
    """CRUD operations for Animal collection in MongoDB"""

    def __init__(self, username: str, password: str):
        """
        Initialize MongoDB connection
        """

        try:
            self.client = MongoClient(
                f"mongodb://{username}:{password}@localhost:27017/?authSource=admin"
            )

            self.database = self.client["aac"]
            self.collection = self.database["animals"]

            # -------------------------
            # DATABASE ENHANCEMENTS
            # -------------------------

            self.collection.create_index("animal_id", unique=True)

            self.collection.create_index(
                [
                    ("breed", 1),
                    ("sex_upon_outcome", 1)
                ]
            )

            self.collection.create_index("name")

        except PyMongoError as e:
            print(f"Database Connection Error: {e}")

    # --------------------------------------------------
    # CREATE
    # --------------------------------------------------

    def create(self, data: Dict) -> bool:

        if not isinstance(data, dict):
            return False

        if len(data) == 0:
            return False

        try:

            self.collection.insert_one(data)

            return True

        except PyMongoError as e:

            print(f"Create Error: {e}")

            return False

    # --------------------------------------------------
    # READ
    # --------------------------------------------------

    def read(self, query: Dict = None) -> List[Dict]:

        if query is None:
            query = {}

        try:

            cursor = self.collection.find(query)

            return list(cursor)

        except PyMongoError as e:

            print(f"Read Error: {e}")

            return []

    # --------------------------------------------------
    # UPDATE
    # --------------------------------------------------

    def update(self, query: Dict, new_values: Dict) -> int:

        if not isinstance(query, dict):
            return 0

        if not isinstance(new_values, dict):
            return 0

        try:

            result = self.collection.update_many(

                query,

                {"$set": new_values}

            )

            return result.modified_count

        except PyMongoError as e:

            print(f"Update Error: {e}")

            return 0

    # --------------------------------------------------
    # DELETE
    # --------------------------------------------------

    def delete(self, query: Dict) -> int:

        if not isinstance(query, dict):
            return 0

        try:

            result = self.collection.delete_many(query)

            return result.deleted_count

        except PyMongoError as e:

            print(f"Delete Error: {e}")

            return 0

    # --------------------------------------------------
    # DATABASE ENHANCEMENT
    # SEARCH
    # --------------------------------------------------

    def searchByBreed(self, breed: str):

        try:

            return list(

                self.collection.find(

                    {

                        "breed": {

                            "$regex": breed,

                            "$options": "i"

                        }

                    }

                )

            )

        except PyMongoError as e:

            print(f"Search Error: {e}")

            return []

    # --------------------------------------------------
    # DATABASE ENHANCEMENT
    # AGGREGATION PIPELINE
    # --------------------------------------------------

    def countAnimalsByBreed(self):

        pipeline = [

            {

                "$group": {

                    "_id": "$breed",

                    "count": {

                        "$sum": 1

                    }

                }

            },

            {

                "$sort": {

                    "count": -1

                }

            }

        ]

        try:

            return list(

                self.collection.aggregate(pipeline)

            )

        except PyMongoError as e:

            print(f"Aggregation Error: {e}")

            return []

    # --------------------------------------------------
    # DATABASE ENHANCEMENT
    # VALIDATION
    # --------------------------------------------------

    def validateDocument(self, document: Dict):

        required_fields = [

            "animal_id",

            "breed",

            "name"

        ]

        for field in required_fields:

            if field not in document:

                return False

        return True