"""
CRUD_Python_Module.py

Author: Hamna Khalid
Course: CS-340 Client/Server Development
Enhanced for CS-499 Computer Science Capstone

Description:
This module provides Create, Read, Update, and Delete (CRUD)
operations for the Grazioso Salvare Animal Shelter MongoDB database.
The enhanced version improves maintainability, readability,
error handling, logging, validation, and documentation.
"""

from pymongo import MongoClient
from pymongo.errors import PyMongoError
from typing import Dict, List, Optional
import logging

# ------------------------------------------------------------
# Logging Configuration
# ------------------------------------------------------------

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

logger = logging.getLogger(__name__)


class AnimalShelter:
    """
    Provides CRUD operations for the Grazioso Salvare
    Animal Shelter MongoDB collection.
    """

    DATABASE_NAME = "aac"
    COLLECTION_NAME = "animals"

    def __init__(self, username: str, password: str):
        """
        Initializes a MongoDB connection.

        Parameters
        ----------
        username : str
            MongoDB username

        password : str
            MongoDB password
        """

        try:
            self.client = MongoClient(
                f"mongodb://{username}:{password}@localhost:27017/?authSource=admin"
            )

            # Verify connection
            self.client.admin.command("ping")

            self.database = self.client[self.DATABASE_NAME]
            self.collection = self.database[self.COLLECTION_NAME]

            logger.info("Successfully connected to MongoDB.")

        except PyMongoError as error:
            logger.error(f"MongoDB Connection Error: {error}")
            raise

    # --------------------------------------------------------
    # Validation Helpers
    # --------------------------------------------------------

    @staticmethod
    def _is_valid_dictionary(data: Optional[Dict]) -> bool:
        """
        Validates that an object is a non-empty dictionary.
        """
        return isinstance(data, dict) and len(data) > 0

    # --------------------------------------------------------
    # CREATE
    # --------------------------------------------------------

    def create(self, data: Dict) -> bool:
        """
        Inserts a document into the collection.

        Parameters
        ----------
        data : Dict
            Document to insert.

        Returns
        -------
        bool
            True if successful, otherwise False.
        """

        if not self._is_valid_dictionary(data):
            logger.warning("Create failed: Invalid input document.")
            return False

        try:
            self.collection.insert_one(data)
            logger.info("Document inserted successfully.")
            return True

        except PyMongoError as error:
            logger.error(f"Create Error: {error}")
            return False

    # --------------------------------------------------------
    # READ
    # --------------------------------------------------------

    def read(self, query: Optional[Dict] = None) -> List[Dict]:
        """
        Retrieves documents matching the specified query.

        Parameters
        ----------
        query : Dict, optional
            MongoDB query filter.

        Returns
        -------
        List[Dict]
            Matching documents.
        """

        if query is None:
            query = {}

        if not isinstance(query, dict):
            logger.warning("Read failed: Query must be a dictionary.")
            return []

        try:
            documents = list(self.collection.find(query))
            logger.info(f"{len(documents)} document(s) retrieved.")
            return documents

        except PyMongoError as error:
            logger.error(f"Read Error: {error}")
            return []

    # --------------------------------------------------------
    # UPDATE
    # --------------------------------------------------------

    def update(self, query: Dict, new_values: Dict) -> int:
        """
        Updates documents matching the query.

        Parameters
        ----------
        query : Dict
            Search criteria.

        new_values : Dict
            Updated field values.

        Returns
        -------
        int
            Number of modified documents.
        """

        if not (
            self._is_valid_dictionary(query)
            and self._is_valid_dictionary(new_values)
        ):
            logger.warning("Update failed: Invalid query or update values.")
            return 0

        try:
            result = self.collection.update_many(
                query,
                {"$set": new_values}
            )

            logger.info(f"{result.modified_count} document(s) updated.")
            return result.modified_count

        except PyMongoError as error:
            logger.error(f"Update Error: {error}")
            return 0

    # --------------------------------------------------------
    # DELETE
    # --------------------------------------------------------

    def delete(self, query: Dict) -> int:
        """
        Deletes documents matching the query.

        Parameters
        ----------
        query : Dict
            Search criteria.

        Returns
        -------
        int
            Number of deleted documents.
        """

        if not self._is_valid_dictionary(query):
            logger.warning("Delete failed: Invalid query.")
            return 0

        try:
            result = self.collection.delete_many(query)

            logger.info(f"{result.deleted_count} document(s) deleted.")
            return result.deleted_count

        except PyMongoError as error:
            logger.error(f"Delete Error: {error}")
            return 0

    # --------------------------------------------------------
    # CLOSE CONNECTION
    # --------------------------------------------------------

    def close(self) -> None:
        """
        Closes the MongoDB connection.
        """

        try:
            self.client.close()
            logger.info("MongoDB connection closed.")

        except Exception as error:
            logger.error(f"Error closing connection: {error}")