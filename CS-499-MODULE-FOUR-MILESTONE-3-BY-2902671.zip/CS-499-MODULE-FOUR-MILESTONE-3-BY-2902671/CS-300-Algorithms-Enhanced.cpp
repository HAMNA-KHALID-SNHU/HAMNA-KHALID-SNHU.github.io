//============================================================================
// Name        : CS-300-PROJECT-TWO-BY-2902671.cpp Enhanced For CS-499
// Author      : HAMNA KHALID
// Version     : 2.0
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style Enhanced For CS-499
/*
 * CS-300 DSA: Analysis and Design
 * Project Two – Advising Assistance Program

 ENHANCED FOR CS-499: Computer Science Capstone
 Milestone 3 Enhancement 2
 *
 * Author: HAMNA KHALID
 * SNHU ID: 2902671
 * Professor: JACK LUSBY
 * Date: August 22, 2026
 *
 * Description:
 * This program reads a list of Computer Science courses and their prerequisites,
 * stores them in a hash-based table, and allows users to view the full course list
 * or search for individual courses. The data is loaded from a CSV file and displayed
 * in alphanumeric order. Menu options allow loading, listing, searching, and exiting.
 */

//============================================================================

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <map>
#include <vector>
#include <algorithm>
#include <queue>
#include <set>
#include <unordered_map>
#include <unordered_set>
#include <limits>

using namespace std;

// ===================== STRUCT FOR COURSE =====================
struct Course {
    string courseNumber;
    string title;
    vector<string> prerequisites;
};

// ===================== HASH TABLE USING MAP =====================
typedef map<string, Course> CourseTable;

// ===================== FUNCTION DECLARATIONS =====================
void loadCourses(CourseTable& courses, const string& fileName);
void printCourseList(const CourseTable& courses);
void printCourse(const CourseTable& courses, const string& courseNumber);
void displayMenu();

// ===================== LOAD COURSES FROM FILE =====================
void loadCourses(CourseTable& courses, const string& fileName) {
    ifstream file(fileName);

    if (!file.is_open()) {
        cout << "Error: Unable to open file '" << fileName << "'." << endl;
        return;
    }

    courses.clear();
    string line;

    while (getline(file, line)) {
        if (line.empty()) continue;

        stringstream ss(line);
        string courseNumber, title, prereq;
        vector<string> prereqs;

        getline(ss, courseNumber, ',');
        getline(ss, title, ',');

        // collect remaining prerequisites
        while (getline(ss, prereq, ',')) {
            prereqs.push_back(prereq);
        }

        Course c;
        c.courseNumber = courseNumber;
        c.title = title;
        c.prerequisites = prereqs;

        courses[courseNumber] = c;
    }

    file.close();
    cout << "Courses loaded successfully from '" << fileName << "'!" << endl;
}

// ===================== PRINT ALL COURSES =====================
void printCourseList(const CourseTable& courses) {
    if (courses.empty()) {
        cout << "Error: No courses loaded yet. Please load data first." << endl;
        return;
    }

    vector<string> keys;
    for (const auto& pair : courses) {
        keys.push_back(pair.first);
    }

    sort(keys.begin(), keys.end()); // ensure alphanumeric order

    cout << "\nHere is a sample schedule:\n" << endl;
    for (const auto& key : keys) {
        cout << key << ", " << courses.at(key).title << endl;
    }
    cout << endl;
}

// ===================== PRINT A SPECIFIC COURSE =====================
void printCourse(const CourseTable& courses, const string& courseNumber) {
    auto it = courses.find(courseNumber);

    if (it == courses.end()) {
        cout << "Error: Course not found." << endl;
        return;
    }

    const Course& c = it->second;
    cout << c.courseNumber << ", " << c.title << endl;

    if (!c.prerequisites.empty()) {
        cout << "Prerequisites: ";
        for (size_t i = 0; i < c.prerequisites.size(); ++i) {
            cout << c.prerequisites[i];
            if (i < c.prerequisites.size() - 1)
                cout << ", ";
        }
        cout << endl;
    } else {
        cout << "Prerequisites: None" << endl;
    }
}

unordered_map<string, vector<string>> buildGraph(const CourseTable& courses) {

    unordered_map<string, vector<string>> graph;

    for (const auto& pair : courses) {

        if (!graph.count(pair.first))
            graph[pair.first] = {};

        for (const string& prereq : pair.second.prerequisites) {

            graph[prereq].push_back(pair.first);

        }

    }

    return graph;

}

// ===================== DFS CYCLE DETECTION =====================

bool dfsCycle(
    const string& course,
    const unordered_map<string, vector<string>>& graph,
    unordered_set<string>& visited,
    unordered_set<string>& recursionStack) {

    visited.insert(course);
    recursionStack.insert(course);

    auto it = graph.find(course);

    if (it != graph.end()) {

        for (const string& prereq : it->second) {

            if (!visited.count(prereq)) {

                if (dfsCycle(prereq, graph, visited, recursionStack))
                    return true;

            }
            else if (recursionStack.count(prereq)) {

                return true;

            }

        }

    }

    recursionStack.erase(course);

    return false;
}

bool hasCycle(const unordered_map<string, vector<string>>& graph) {

    unordered_set<string> visited;
    unordered_set<string> recursionStack;

    for (const auto& pair : graph) {

        if (!visited.count(pair.first)) {

            if (dfsCycle(pair.first,
                         graph,
                         visited,
                         recursionStack))

                return true;

        }

    }

    return false;

}

// ===================== TOPOLOGICAL SORT =====================

vector<string> topologicalSort(
    const unordered_map<string, vector<string>>& graph) {

    unordered_map<string, int> indegree;

    for (const auto& pair : graph) {

        if (!indegree.count(pair.first))
            indegree[pair.first] = 0;

        for (const string& prereq : pair.second) {

            indegree[pair.first]++;

        }

    }

    queue<string> q;

    for (const auto& pair : indegree) {

        if (pair.second == 0)

            q.push(pair.first);

    }

    vector<string> order;

    while (!q.empty()) {

        string current = q.front();

        q.pop();

        order.push_back(current);

        auto it = graph.find(current);

        if (it != graph.end()) {

            for (const string& prereq : it->second) {

                indegree[prereq]--;

                if (indegree[prereq] == 0)

                    q.push(prereq);

            }

        }

    }

    return order;

}

// ===================== VALIDATE PREREQUISITES =====================

void validatePrerequisites(const CourseTable& courses) {

    bool errors = false;

    cout << "\nChecking prerequisite integrity...\n\n";

    for (const auto& pair : courses) {

        for (const string& prereq : pair.second.prerequisites) {

            if (courses.find(prereq) == courses.end()) {

                cout
                    << "Missing prerequisite "
                    << prereq
                    << " referenced by "
                    << pair.first
                    << endl;

                errors = true;

            }

        }

    }

    if (!errors) {

        cout << "All prerequisite references are valid.\n";

    }

}

// ===================== DISPLAY COURSE PLAN =====================

void displayCoursePlan(const CourseTable& courses) {

    auto graph = buildGraph(courses);

    if (hasCycle(graph)) {

        cout << "\nERROR: Cycle detected in prerequisite graph.\n";

        return;

    }

    vector<string> order = topologicalSort(graph);

    cout << "\nSuggested Course Plan\n";
    cout << "=========================\n";

    for (const string& course : order) {

        auto it = courses.find(course);

        if (it != courses.end()) {

            cout

                << it->second.courseNumber

                << ", "

                << it->second.title

                << endl;

        }

    }

}



// ===================== DISPLAY MENU =====================
void displayMenu() {

    cout << "\n1. Load Data Structure." << endl;

    cout << "2. Print Course List." << endl;

    cout << "3. Print Course." << endl;

    cout << "4. Display Suggested Course Plan." << endl;

    cout << "5. Validate Prerequisites." << endl;

    cout << "6. Exit" << endl;

}

// ===================== MAIN FUNCTION =====================
int main() {
    CourseTable courses;
    string fileName;
    int choice = 0;
    bool dataLoaded = false;

    cout << "Welcome to the course planner." << endl;

    while (true) {
        displayMenu();
        cout << "Enter choice: ";
        cin >> choice;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        if (choice == 1) {
            cout << "Enter the filename of the course data (or press Enter for default ABCU_Advising_Program_Input.csv): ";
            getline(cin, fileName);

            if (fileName.empty()) {
                fileName = "ABCU_Advising_Program_Input.csv";
                cout << "Using default file: " << fileName << endl;
            }

            loadCourses(courses, fileName);
            if (!courses.empty()) dataLoaded = true;

        } else if (choice == 2) {
            if (!dataLoaded) {
                cout << "Error: No courses loaded yet. Please load the file first (Option 1)." << endl;
            } else {
                printCourseList(courses);
            }

        } else if (choice == 3) {
            if (!dataLoaded) {
                cout << "Error: No courses loaded yet. Please load the file first (Option 1)." << endl;
            } else {
                cout << "What course do you want to know about? ";
                string courseNum;
                getline(cin, courseNum);
                printCourse(courses, courseNum);
            }

        } else if (choice == 4) {

    if (!dataLoaded) {

        cout << "Load the course data first.\n";

    }
    else {

        displayCoursePlan(courses);

    }

}

else if (choice == 5) {

    if (!dataLoaded) {

        cout << "Load the course data first.\n";

    }
    else {

        validatePrerequisites(courses);

    }

}

else if (choice == 6) {

    cout << "\nThank you for using the course planner.\n";

    break;

}

else {

    cout << "Invalid selection.\n";

}
    }
}
 